# 1. x86系统架构概览
主要对IA-32系统总体架构内容做了部分整理。
## 1.1 系统级体系结构概览
![ia-32](images/ia-32.png)
### 1.1.1 全局和局部描述符表（Global and Local Descriptor Tables）
保护模式下，处理器必须通过 **全局描述符表(GDT)或局部描述符表(LDT)** 才能访存，它们实际为段描述符组成的数组，段描述符提供了段的基地址、访问权限、类型、使用信息等内容。

而段描述符需要通过 **段选择符(segment selector)** 来访问，其包含描述符是全局还是局部的、访问权限等信息。

对于段中某个字节的访问需要 **段选择符和偏移量** ，前者通过描述符获得基地址，在加上后者后者准确地址，代码、数据和栈段均如此访问。此外，**访问存在权限级别限制，共4级(0-3)，数越小级别越高，每个级别各自有一个栈**。

GDT和LDT的线性地址分别存储在 **GDTR** 和 **LDTR** 两个寄存器中。
### 1.1.2 系统段
系统段除了代码段、数据段和栈段，还有任务状态段(Task-state Segment/TSS)和LDT。（注：**GDT和LDT[中断描述符表，后序会提到]不认为是段，因为它们通过特定寄存器来访问而非段选择符和段描述符的方式**）
### 1.1.3 门(Gate)
门是一种特殊的描述符，它们可以实现跨级别权限的访问。
### 1.1.4 TSS和任务门(Task Gate)
TSS定义了一个任务执行环境的状态，包括各类寄存器（通用、EFLAGS、EIP等）、栈的段选择符、该任务相关的LDT的段选择符、页表(paging-structure hierarchy?)基地址等。

TSS的段选择符存在Task Registor(TR)中，切换任务可通过call/jmp+TSS段选择符来实现。切换任务步骤如下：
* 当前任务状态存入对应TSS；
* 新任务段选择符存入TR；
* 通过GDT段描述符访问新的TSS；
* 加载新任务状态到各个寄存器；
* 执行新任务。
访问任务还可以通过任务门实现。
### 1.1.5 中断和异常处理
外部中断、软件中断和异常都通过中断描述符表(Interrupt Descriptor Table/IDT)来处理。IDT实际是一个门描述符数组，这些门用于访问中断和异常处理程序，类型包括中断、陷阱或任务门。处理器首先会收到一个中断向量(interrupt vector)，以此为IDT的索引找到对应描述符执行相关程序。
### 1.1.6 内存管理
内存管理依据是否分页分为两种。
## 1.2 支持的模式以及模式转换
### 1.2.1 IA-32支持的几种运行模式
* **保护模式(protected mode)**：这是处理器的原生操作模式，特性丰富，应该算是处理器的“主模式”。
* **实模式(real-address mode)**：此模式下处理器可以跑intel 8086程序。通常处理器以实模式启动，然后转保护模式进行正常工作。
* **系统管理模式(system management mode/SMM)**：该模式下，OS可进行电源管理和OEM(Original Equipment Manufacturer)差异特性的实现。
* **虚拟8086模式(virtual-8086 mode)**：在保护模式下跑8086程序。（有点虚拟机的感觉）
### 1.2.2 模式转换
以上四种模式的转换方式如下图所示（其中的IA-32e是64b对32b的兼容模式，暂未整理）。
![mode_transition](images/mode_transition.png)
从图中可以看出除了进入SMM需要通过**中断码SMI#**，其余模式转换均是利用寄存器中的**标志位**实现的。
* 保护模式 VS 实模式：CR0中的PE标志位实现转换。此外，在处理器开启或重启时，会优先进入实模式，并将系统数据结构和代码模型加载入内存作软件初始化，然后转入保护模式。
* 保护模式 VS 虚拟8086模式：EFLAGS中的VM标志位实现转换。
* SMM：任意其他模式在收到SMI中断后转入该模式，并通过执行RSM指令恢复原模式。
## 1.3 x86系统指令寄存器
### 1.3.1 标志寄存器<font color=#ff0000>EFLAGS</font>
![EFLAGS](images/EFLAGS.png)
EFLAGS寄存器内部结构如上图所示，其记录程序状态，有多个控制位，用于IO控制、硬件中断、任务转换等功能的实现。以下列举了用于控制OS或执行操作的标志位：
* TF **Trap**(bit 8) ：置1进入单步调试模式。
* IF **Interrupt Enable** (bit 9) ：控制处理器对可屏蔽中断请求的响应。置1则响应可屏蔽中断请求，否则禁止响应。
* IOPL **I/O Privilege Level Field** (bit 12-13) ：指示当前程序的IO优先级。当前程序优先级（CPL）小于等于IOPL时才可访问IO地址空间。
* NT **Nested Task** (bit 14) ：控制中断链和被调用任务。若两个相邻任务相关，即后者通过call指令、中断(interrupt)或异常(exception)被调用，则置1。
* RF **Resume** (bit 16) ：控制处理器对调试异常(debug exception)的响应。置1则不响应。
* VM **Virtual-8086 Mode** (bit 17) ：控制实模式和虚拟8086模式的转换。
* AC **Alignment Check** (bit 18) ：该位与CR0中的AM为都置1时，允许执行内存引用的对其检查。
* VIF **Virtual Interrupt** (bit 19) ：IF的虚拟镜像，和VIP标志结合使用。
* VIP **Virtual Interrupt Pending** (bit 20) ：存在中断被挂起时置1，无中断挂起时置0。
* ID **Identification** (bit 21) ：指示对CPUID指令的支持。
### 1.3.2 内存管理寄存器（Memory Management Registers）
![mmr](images/mmr.png)
处理器提供了4个内存管理寄存器（<font color=#ff0000>GDTR, LDTR, IDTR, TR</font>），用于控制分段内存管理。这些寄存器均为段基址寄存器，前三者在开机或重启时，基地址为0，表长(table limit)为0xFFFF。
* GDTR：存放GDT的32位线性基地址和16位表长。保护模式初始化时，需要给其加载一个新值。相关指令有LGDT, SGDT...
* LDTR: 存放LDT的32位线性基地址和16位表长。相关指令有LLDT, SLDT...
* IDTR: 存放IDT的32位线性基地址和16位表长。相关指令有LIDT, SIDT...
* TR: 存放当前任务TSS的16为段选择符(segment selector)、32位基地址、段长(segment limit)以及描述符(descriptor)。其中选择符引用的是GDT中某个TSS的描述符。当发生任务切换时，该寄存器会自动加载新任务的段选择符和描述符。
### 1.3.3 控制寄存器（Control Registers）
![cr](images/cr.png)
共有5个控制寄存器（CR0, CR1, CR2, CR3, CR4），用于确定处理器的操作模式以及当前任务的特性。
* **CR0**: 包含控制操作模式和处理器状态的标志位。
* **CR1**: 未定义，应该是预留给未来处理器作功能扩展。
* **CR2**: 存储导致页错误(page fault)的线性地址。
* **CR3**: 31-12位存储页目录基地址，另存在两个标志位Page-level Cache Disable(PCD)和Page-level Write-Through(PWT)。PCD控制是否对当前页目录进行缓存，置1禁止，置0允许；PWT控制页目录的缓存方式，置1为write-through(直写)，置0位write-back(写回)。
* CR4: 主要与虚拟8086模式相关。
## 1.4 系统指令
主要介绍与内存管理寄存器相关的几条指令。
* GDTR
    > LGDT: 加载GDTR的内容\
    > SGDT: 保存GDTR的内容
* LDTF
    > LLDT: 加载LDTR段选择符的部分，当段选择符被加载如LDTR中后，相应的基地址、表长、描述符会被自动加载入LDTR\
    > SLDT: 保存LDTR段描述符的部分
* IDTR
    > LIDT: 加载IDTR的内容\
    > SIDT: 保存IDTR的内容
* TR
    > LTR: 加载TR段选择符的部分，当段选择符被加载如LDTR中后，相应的基地址、表长、描述符会被自动加载入TR\
    > STR: 保存TR段选择符的部分





