# 2. 保护模型内存管理
## 2.1 内存管理概览
<div align="center"><img src="images/segmentation_paging.png">Figure 2-1. Segmentation and Paging</div>
IA-32架构的内存管理可分为两部分：分段（segmentation）和分页（paging）。

### **2.1.1 分段**

分段机制实现了各个程序的代码、数据和栈的相互独立互不干扰。如图2-1所示，分段机制将<font color=#ff0000>可寻址存储空间（线性地址空间）</font>分成多个段，每个段用于存储一个程序的代码段、数据段和堆栈段或者存储系统数据结构（如TSS、LDT等）。处理器会确保各个段互不影响，一个程序无法改写另一个程序的段。

一个系统的所有段均在线性地址空间中，而定位段中的某一位需要其<font color=#ff0000>逻辑地址</font>，逻辑地址包含段选择符（可理解为一个段的ID）和偏移量，具体寻址方式在笔记1中已有提到，实际先需要利用段选择符在段描述符表中得到对应的段描述符，然后利用段描述符中的段信息（基地址）以及偏移量实现对线性地址空间的访问。

在未分页情况下，线性地址空间是直接映射到<font color=#ff0000>物理地址空间</font>上的，不过目前大多数情况系的线性地址空间的大小需求远超实际物理存储空间，故还是需要采用分页机制。

### **2.1.2 分页**
分页机制用到了 **虚拟缓存技术** ，要实现<font color=#ff0000>线性地址空间</font>到<font color=#ff0000>物理地址</font>的映射就相对复杂很多，需要用到页目录和页表，但是该项技术可以使内存空间得到更充分的使用，使得在有限的内存的条件下处理器能运行更多的程序。

## 2.2 段的使用
IA-32架构使用分段机制实现了多种系统设计，其中包括仅最小限度使用分段来保护程序的平坦模型（flat models），能够实现一个多程序和任务可靠执行的操作环境的多任务模型（multi-segmented models）等。

### **2.2.1 基本平坦模型（Basic flat model）**
<div align="center"><img src="images/flat_model.png">Figure 2-2. Flat Model</div>
如图2-2所示，基本平坦模型至少有两个段描述符，一个引用代码段，一个引用数据段，而这些段都被映射到整个线性地址空间上。在基本平坦模型中，分页机制仅限制段大小为4GB而不做其他保护措施。即使访问的线性地址空间没有被映射到物理地址空间，也不会返回异常。

### **2.2.2 保护平坦模型（Protected flat model）**
<div align="center"><img src="images/protected_flat_model.png">Figure 2-3. Protected Flat Model</div>
保护平坦模型将程序访存限制在已经映射到物理地址空间的那些线性地址中，对于访问不存在的存储空间（未映射物理地址），会产生一个GP异常（general-protection exception/#GP）。这种模型实际提供了最低限度的硬件保护措施，在此基础上，实际可以扩展出更多的保护机制。

### **2.2.3 多段模型（Multi-Segment model）**
<div align="center"><img src="images/multi-segment_model.png">Figure 2-4. Multi-Segment Model</div>
多段模型最大程度上地利用分段机制来对代码、数据以及程序和任务提供硬件保护。如图2-4所示，每个程序/任务都有各自的段和段描述符表，每个段仅对其对应的一个或多个程序开放。在多段模型中，还需要进行权限检查，这不仅限制了程序访问其段以外的内容，还防止程序在某些段执行一些禁止的操作。

## 2.3 物理地址、逻辑地址和线性地址
在保护模型中，处理器需要两步来获得物理地址：逻辑地址翻译（logical-address translation）和线性地址空间页映射（linear address space paging）。当然若未采取分页，则线性地址空间直接映射到物理地址空间。

### **2.3.1 物理地址**
物理地址就是实际的内存地址，即处理器在地址总线上寻址所用的地址。若没有分页，则线性地址就是物理地址（直接映射）；若有分页，则线性地址借助页目录和页表映射为物理地址。

IA-32架构提供4GB物理地址空间，而奔腾pro处理器开始物理空间扩展为64GB。

### **2.3.2 逻辑地址和线性地址的转换**
<div align="center"><img src="images/logical_to_linear.png">Figure 2-5. Logical Address to Linear Address Translation</div>
线性地址转换为逻辑地址（段选择符+偏移量）的步骤如下：

* 利用段选择符中的偏移量从GDT/LDT中得到对应段描述符（这步仅在新的段选择符加载到段寄存器时必要）；
* 检查段是否可访问以及段偏移量是否合法；
* 利用偏移量和描述符中的基地址得到线性地址。

### **2.3.3 段选择符**
<div align="center"><img src="images/selector.png">Figure 2-6. Segment Selector</div>
段选择符共有16位，它并不直接指向段，而是指向段描述符，其结构如下：

* **Index**（15-3）:GDT/LDT中8192个描述符的地址。处理器寻址时按下式计算：<div align="center">Address(descriptor) = Address(GDT/LDT) + Index $\times$ 8</div>
* **TI(table indicator) flag**（2）：选择GDT或LDT，0-GDT，1-LDT
* **Requested Privilege Level (RPL)**（1-0）：标识选择符的特权级（0-3，越小越高）

GDT的首个元素并不会被处理器使用，通常由一个“空选择符(null segment selector)”指向它。该选择符的一个功能是用于初始化除了CS和CC以外的段寄存器（用于缓存段选择符）。

尽管段选择符对于应用程序是可见的，但其值通常有链接编辑器或链接加载器指定或修改。

### **2.3.4 段寄存器**
<div align="center"><img src="images/register.png">Figure 2-7. Segment Registers</div>
处理器提供了6个用于存储段选择符的段寄存器来降低地址转换时间和代码复杂度，分别是CS(code), DS(data), SS(stack), ES(data), FS(data), GS(data)，这也决定了一个系统某时刻至多只有6个段可用。

如图2-7所示，每个段寄存器分为可见部分（visible part）和隐藏部分（hidden part）。段选择符会被加载到可见部分，处理器会通过段选择符将基地址、段长(segment limit)、段描述符指向的访问控制信息存入隐藏部分。段寄存器的缓存作用帮助处理器降低了地址转换导致的访问总线周期开销。

加载段寄存器的两类指令：
* 直接加载指令，如 MOV, POP, LDS, LES, LSS, LGS, LFS等，这些指令需要**显示引用**段寄存器；
* 间接加载指令，如 CALL, JMP, RET, SYSENTER,  SYSEXIT, IRET, INTn, INTO, INT3等，这些指令通常会修改CS寄存器（**隐式引用**）。

## 2.4 段描述符
<div align="center"><img src="images/descriptor.png">Figure 2-8. Segment Descriptor</div>
段描述符是存储在GDT/LDT中的一种数据结构，其结构如图2-8所示，其中包含段的大小、位置、访问权限、状态信息等。其通常由编译器、链接器、加载器或操作系统创建而非应用程序。段描述符各位具体含义如下：

* **Segment limit field**：指定段大小。若G=0，则大小1B-1MB，单位增量1B；若G=1，则大小4KB-4GB，单位增量4KB。
*  **Base address fields**：指定段内存的基地址。
*  **Type field**：指明段/门的类型，确定段的访问权限以及增长方式。
*  **S (descriptor type) flag**：确定该描述符是系统描述符（flag=0）还是代码或数据描述符（flag=1）。
*  **DPL (descriptor privilege level) field**：确定段的特权级别以控制段的访问。
*  **P (segment-present) flag**：确定段是否在内存中，flag=1存在，flag=0不存在且当一个段选择符指向它时处理器会产生#NP异常(segment-not-present exception)。
*  **D/B (default operation size/default stack pointer size and/or upper bound) flag**：该位具体作用取决于其所对应的段种类。
    >* 可执行代码段：该位指定了段内有效地址以及操作数引用的默认长度。1-32位地址 & 32/8位操作数；2-16位地址 & 16/8位操作数。
    >* 堆栈段：指定栈指针大小。1-32位；0-16位。
    >* 向下扩展数据段：指定段下界。1-FFFFFFFFH(4GB)；0-FFFFH(64KB)。
*  **G (granularity) flag**：决定了段长的最小增量（粒度），具体见上方**Segment limit field**。
*  **L (64-bit code segment) flag**：用于在IA-32e模型中确定是采取64位模式（flag=1）还是采取兼容/32位模式（flag=0）。
*  **Available and reserved bits**：预留位供系统软件使用。

### **2.4.1 代码和数据段描述符**
<div align="center"><img src="images/code_data_segment.png">Figure 2-9. Code- and Data-Segment Types</div>

当 **S(descriptor type)flag** 被置1时，该段为代码或数据段。**Type field** 决定了该段的最终种类以及其各类权限，具体可见图2-9。

堆栈段实际就是可读写的数据段。若将一个不可写段选择符加载到SS中，则会产生#GP异常。若堆栈段大小需要动态变化，则expansion-direction位（E位）置1，否则置0。

代码段可以是一致段也可以是不一致段，而数据段都是不一致段。一致段允许低权限调用高权限代码，而不一致段不允许这么做，除非使用笔记1中提到的调用门(call gate)或任务门(task gate)。

### **2.4.2 系统描述符**
<div align="center"><img src="images/system_gate.png">Figure 2-10. System-Segment and Gate-Descriptor Types</div>

当 **S(descriptor type)flag** 被置0时，该描述符为系统描述符。系统描述符有以下几类：
* Local descriptor-table (LDT) segment descriptor
* Task-state segment (TSS) descriptor
* Call-gate descriptor
* Interrupt-gate descriptor
* Trap-gate descriptor
* Task-gate descriptor

前两者为系统段描述符，后四者为门描述符，图2-10展示了不同种类描述符对应的 **Type field** 。

在笔记1中已提过GDT不是段，它是存储在内存中的一个数据结构，处理器通过GDTR访问GDT。而LDT的段选择符就在GDT当中。每个系统有一个GDT，而LDT可以有一个或多个来对应多个任务，我认为这应该是GDT不以段形式定义而LDT是段的一个原因。



