# 4. 系统调用

## 4.1 实验目的
* 建立对系统调用接口的深入认识
* 掌握系统调用的基本过程
* 能完成系统调用的全面控制
* 为后续实验做准备

## 4.2 实验内容
### 4.2.1 实现sys_iam()和sys_whoami()
1. iam()完成的功能是将字符串参数 name 的内容拷贝到内核中保存下来。 要求 name 的长度不能超过23个字符。返回值是拷贝的字符数。 如果 name 的字符个数超过了23，则返回-1，并置 errno 为 EINVAL 。其实现如下：
```
char msg[24]; // 23字符+'\0'
int sys_iam(const char * name)
{
    int i = 0;
    char tmp[30]; // 临时存储字符串
    do {
        tmp[i] = get_fs_byte(name + i);
    } while(i <= 30 && tmp[i++] != '\0');
    if (i-- > 24) // 字符串过长
        return -(EINVAL);
    strcpy(msg, tmp);
    return i;
}
```
2. whoami()将内核中由 iam() 保存的名字拷贝到 name 指向的用户地址空间中，同时确保不会对 name 越界访存（name 的大小由 size 说明）。返回值是拷贝的字符数。如果 size 小于需要的空间，则返回-1，并置 errno 为 EINVAL 。其实现如下：
```
int sys_whoami(char* name, unsigned int size)
{
    int len = 0;
    for(;msg[len]!='\0';len++);
    if (len > size) // 字符串过长
        return -(EINVAL);
    int i;
    for (i=0; i<len; i++) 
        put_fs_byte(msg[i], name + i);
    return len;
}
```
### 4.2.2 在Linux0.11内核中添加系统调用
操作系统通过如下操作实现系统调用：
* 应用程序调用库函数；
* 库函数那个系统调用号存入EAX，函数参数存入其他寄存器，然后通过中断调用使系统进入内核态；
* 内核中中断处理函数根据系统调用号，调用对应的内核函数（系统调用）；
* 系统调用函数执行后，将结果存入EAX并返回中断处理函数；
* 中断处理函数返回库函数；
* 库函数将EAX返回给应用程序。
  
根据以上过程，我们知道，每个内核系统调用函数均对应一个系统调用号，因此我们需要为iam()和whoami()也分配系统调用号。此外，linux0.11中维护了一个存储所有系统调用函数指针的数组sys_call_table，因此我们还需要将iam()和whoami()也添加入其中。最后，还需要适当修改makefile文件，这样才能在编译时将这两个系统调用真正加入到Linux0.11内核中。

综上，需要对Linux0.11文件做如下修改：
* 在include/unistd.h文件中添加iam和whoami系统调用号的宏定义，由于已经定义了72个系统调用，故iam和whoami系统调用号为72和73；
```
#define __NR_iam		72
#define __NR_whoami		73
```
* 将kernel/system_call.s中记录系统调用总数的变量nr_system_calls改为74；
```
nr_system_calls = 74
```
* 在数组sys_call_table中添加sys_iam()和sys_whoami()，该数组在文件include/linux/sys.h中；
```
extern int sys_iam();
extern int sys_whoami();

fn_ptr sys_call_table[] = { ...,sys_iam,sys_whoami };
```
* 将iam()和whoami()的具体实现文件who.c保存到kernel文件夹下，并修改kernel中的MakeFile，以添加who.c文件的编译。
```
OBJS  = ... who.o
who.s who.o: who.c ../include/linux/kernel.h ../include/unistd.h
```
### 4.2.3 系统调用的测试
首先在Ubuntu下分别编写了iam.c和whoami.c程序测试两个添加的系统调用，测试程序内容如下：

iam.c:
```
#define __LIBRARY__
#include <errno.h>
#include <unistd.h>
#include <stdio.h>

_syscall1(int, iam, const char*, name);

int main(int argc,char ** argv)
{
	iam(argv[1]);
	return 0;
}
```
whoami.c:
```
#define __LIBRARY__
#include <errno.h>
#include <unistd.h>

_syscall2(int, whoami,char*,name,unsigned int,size);

int main()
{
	char s[30];
	whoami(s,30);
	printf("%s",s);
	return 0;
}
```
然后，通过挂载方式实现宿主机到虚拟机的文件传输，具体命令如下：
```
sudo ./mount-hdc
cp iam.c whoami.c hdc/usr/root
```
接着，在Linux0.11中编译测试程序。
```
gcc -o iam iam.c
gcc -o whoami whoami.c
```
但在实际编译时，发现Linux0.11无法识别iam，如图1所示。

<div align="center"><img src="images/1.png"><br>Figure 1. 编译错误</div>

查看/usr/include/unistd.h文件时，发现其中并没有iam和whoami系统调用号的宏定义，这应该就是编译报错的原因。于是，利用vim在unistd.h中手动添加两个宏定义，再次编译运行即可，图2为测试结果。

<div align="center"><img src="images/2.png"><br>Figure 2. iam.c和whoami.c运行结果</div>

再编译执行提供的测试程序testlab2.c和测试脚本testlab2.sh，结果如图3。

<div align="center"><img src="images/3.png"><br>Figure 3. testlab2运行结果</div>

## 4.3 实验问题
### 4.3.1 从 Linux 0.11 现在的机制看，它的系统调用最多能传递几个参数？

在include/unistd.h文件中定义了宏函数_syscalln()，n为调用的函数所携带的参数个数。以_syscall1(type,name,atype,a)为例，type为返回值类型，name为调用函数名，atype为第一个参数类型，a为第一个参数。该文件中提供了传递0-3个参数的函数调用实现，故该Linux0.11机制下至多能传3个参数。

### 4.3.2 你能想出办法来扩大这个限制吗？

实际只需使用_syscall2即可实现多个参数的传递。将需要传递的参数以(type, value)的形式连续存储在一段内存中，然后将这段内存的头指针以及参数个数作为参数传递即可，当然也可以不会攒底参数个数，而是在这段参数结构末位设置一个结束符。

### 4.3.3 用文字简要描述向 Linux 0.11 添加一个系统调用 foo() 的步骤。

1. 修改include/unistd.h，添加"#define __NR_foo 74"，为foo()分配系统调用号；
2. 修改kernel/system_call.s，将nr_system_call值加1；
3. 修改include/linux/sys.h，在sys_call_table数组最后添加sys_foo，并添加申明"extern int sys_foo();"；
4. 将foo()的实现文件foo.c放到kernel文件目录下，并修改kernel的MakeFile文件，将foo.c与其他内核代码编译链接到一起；
5. 用户调用时需要添加如下内容：
```
#define __LIBRARY__
#include <unistd.h>
_syscalln(int, foo, ...)
```