#include <string.h>
#include <errno.h>
#include <asm/segment.h>

char msg[24]; // 23字符+'\0'

/*
 * function: 将字符串参数 name 的内容拷贝到内核中保存下来
 * return: 拷贝的字符数，若字符串长度大于23，返回-1，并置error为EINVAL
 */
int sys_iam(const char * name)
{
    int i = 0;
    char tmp[30];
    do {
        tmp[i] = get_fs_byte(name + i);
    } while(i <= 30 && tmp[i++] != '\0');
    if (i-- > 24) {
        //printk("String too long!\n");
        return -(EINVAL);
    }
    strcpy(msg, tmp);
    return i;
}

/*
 * function: 将内核中由 iam() 保存的名字拷贝到 name 指向的用户地址空间中， 同时确保不会对 name 越界访存
 * return: 拷贝的字符数，若size 小于需要的空间，则返回 -1 ，并置 errno 为 EINVAL
 */
int sys_whoami(char* name, unsigned int size)
{
    int len = 0;
    for(;msg[len]!='\0';len++);
    if (len > size) {
        //printk("Size too small!\n");
        return -(EINVAL);
    }
    int i;
    for (i=0; i<len; i++) {
        put_fs_byte(msg[i], name + i);
    }
    return len;
}