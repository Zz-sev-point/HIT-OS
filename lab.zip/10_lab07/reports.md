# 7. 地址映射与共享

## 7.1 实验目的
* 深入理解操作系统的段、页式内存管理，深入理解段表、页表、逻辑地址、线性地址、物理地址等概念；
* 实践段、页式内存管理的地址映射过程；
* 编程实现段、页式内存管理上的内存共享，从而深入理解操作系统的内存管理。

## 7.2 实验内容

### 7.2.1 跟踪地址翻译过程

#### **7.2.1.1 编译并运行测试程序test.c**

在Ubuntu下编写test.c并通过挂载放入linux0.11用户文件夹中，在linux0.11中进行编译运行。
```
/* test.c */
#include <stdio.h>

int i = 0x12345678;

int main(void)
{
    printf("The logical/virtual address of i is 0x%08x", &i);
    fflush(stdout);

    while (i)
        ;

    return 0;
}

/* 挂载 */
./mount-hdc
cp test.c ./hdc/usr/root/

/* linux0.11下编译运行 */
gcc -o test test.c
./test
```
#### **7.2.1.2 调试获得虚拟地址**

test是一个死循环程序，我们的目标是破坏循环条件来结束程序的执行。首先，我们需要定位到循环体的汇编代码。通过运行test过程中的暂停和逐步运行调试，将程序暂停在一句cmp比较指令，并列出以其开始的连续7条指令，这就是test.c的while循环体对应的汇编代码，如图1所示。可以发现，程序将"ds:0x00003004"处的值与0进行比较，仅当两者相等时，循环结束退出。显然ds:0x00003004处存储的就是test.c中i的值，我们要做的就是根据该虚拟地址查询到其对应的物理地址，并手动将其改为0，即可结束程序。

该虚拟地址的"ds"说明该地址在ds段中，偏移值为0x3004，故首先需要找到ds段。

<div align="center"><img src="images/1.png"><br>Figure 1. while循环体的汇编代码</div>

#### 7.2.1.3 查找ds段

通过sreg指令可以在bochs中查看段寄存器、ldtr、gdtr等寄存器的信息，如图2所示。可以发现ds的段选择子值为0x0017，第2位为1，第15-3位为0x10,结合图3段选择子每一位的含义可知，ldt中的第3项即是ds的段描述符。

<div align="center"><img src="images/2.png"><br>Figure 2. 寄存器信息</div>
<div align="center"><img src="images/3.png"><br>Figure 3. 段选择子</div>

故接下来我们需要先找到ldt，而ldt的段描述符是存放在gdt中的，我们需要在gdt中先定位到ldt段描述符。图2中ldtr存储的段选择子为0x0068，索引位（15-3）值为0x1101=13，即ldt的段描述符存放在gdt的第14项。图2中可以看到gdt物理首地址为0x00005cb8，gdt每一项为8B，故ldt描述符首地址为0x5cb8+13*8，如图4所示，ldt段描述符为0xc2d00068 0x000082f9。诗句我们只需要段描述符中的段的基地址信息，根据图5对段描述符的解释，我们可以得到ldt的基地址为0x00f9c2d0。

<div align="center"><img src="images/4.png"><br>Figure 4. ldt段描述符</div>

<div align="center"><img src="images/5.png"><br>Figure 5. 段描述符</div>

根据ldt的基地址以及ds段描述符在ldt中的偏移，我们可以查到ds的段描述符的具体内容，如图6所示，ds段描述符为0x00003ffff 0x10c0f300，由此可得ds段基地址为0x10000000。实际上，图2中ds一行中的dh和dl项就是ds的段描述符，这也验证了我们的查询结果是正确的。

<div align="center"><img src="images/6.png"><br>Figure 6. ds段描述符</div>

#### **7.2.1.4 线性地址转换为物理地址**

根据ds段的基地址以及偏移量可得i存储地址为0x10003004，但这个地址为线性地址，我们还需要将其转化为物理地址，这里需要查找页表，转化过程如图7所示。

<div align="center"><img src="images/7.png"><br>Figure 7. 线性地址转化为物理地址</div>

根据图7可知这是一个二级页表的转化，线性地址被分成10位、10位、12位三部分，最终可以得到0x10003004的页目录号为64，页号为3，页内偏移为4。

IA-32下，页目录表位置由CR3确定。如图8，可通过creg指令查看控制寄存器信息，可知页目录表基地址为0。由此，可查得页目录表第65项为0x00faa027，如图9所示。根据图10，页号为表项的31-12位，故页表号为0x00faa00。再以此查得页表第3项，如图11，表项为0x00fa7067，故物理页号为0x00fa7000。最终，根据物理页号和偏移可得最终物理地址为0x00fa7004，i的值为0x12345678，如图12。

<div align="center"><img src="images/8.png"><br>Figure 8. 控制寄存器信息</div>
<div align="center"><img src="images/9.png"><br>Figure 9. 页表地址</div>
<div align="center"><img src="images/10.png"><br>Figure 10. 表项格式</div>
<div align="center"><img src="images/11.png"><br>Figure 11. 物理页号</div>
<div align="center"><img src="images/12.png"><br>Figure 12. 查询结果</div>

因此，我们只需将物理地址为0x00fa7004处的4字节改为0即可结束程序，如图13所示。

<div align="center"><img src="images/13.png"><br>Figure 13. 修改内存结束程序</div>

### 7.2.2 实现基于共享内存的生产者—消费者程序

#### 7.2.2.1 **实现系统调用shmget和shmat**

首先给出维护共享页表的数据结构shm_ds，其中key为索引键值，size为内存大小，page为实际的内存页号。利用一个shm_ds数组记录所有的共享内存页，key初始值为0。

```
typedef struct shm_hs {
	unsigned int key;
	unsigned int size;
	unsigned long page;
}shm_ds;

static shm_ds shm_list[SHM_SIZE] = {{0, 0, 0}};
```

1. int shmget(key_t key, size_t size)

shmget()的功能是以key为索引，以size为空间大小，打开/新建一页共享内存，并返回该页共享内存的ID，即shmid。若key索引的共享内存不存在则新建，否则直接返回索引到的共享内存页的id。当size大于一页时，函数返回-1，并置errno为EINVAL。如果系统无空闲内存，返回-1，并置errno为ENOMEM。具体代码实现见code/shm.c。

实现伪代码如下。其中，由于key初始值为0，故0不可作为索引值，需要对输入参数key进行检查。新建共享内存页通过调用get_free_page()实现，该函数功能即使获得一个空闲物理页，并返回对应页号。

```
int sys_shmget(unsigned int key, size_t size) {
    if key为初始值0 
        报错并返回-1
    if size大于一页大小
        errno置为ENOMEM，报错并返回-1
    for (i = 0; i < SHM_SIZE; i++) 
        根据key查找共享页，找到则直接返回数组下标i
    新建共享内存页
    if 新建失败
        errno置为ENOMEM，报错并返回-1
    for (i = 0; i < SHM_SIZE; i++) 
        在shm_list中查找一个空闲项记录该共享内存页，并返回该项数组下标作为shmid
    报错并返回-1
}
```

2. void *shmat(int shmid)

shmat()的功能是将shmid指定的共享页面映射到当前进程的虚拟地址空间中，并将其首地址返回。如果shmid非法，返回-1，并置errno为EINVAL。具体代码实现见code/shm.c。

实现伪代码如下。一页空闲的虚拟地址空间我们可以从堆中获得，brk指针指向堆顶，我们只需将brk+PAGE_SIZE即可获得一页空闲的虚拟地址空间，然后再利用put_page()函数将该虚拟空间和shmid对应的物理空间页关联起来即可。

```
void *sys_shmat(int shmid) {
    if shmid非法
        errno置为EINVAL，返回-1
    将当前brk指针加上一页偏移值PAGE_SIZE在堆中获得一页空闲虚拟地址空间
    将空闲的虚拟空间与shmid对应的物理空间关联
    if 关联失败 
        errno置为ENOMEM，返回-1
    返回brk-PAGE_SIZE
}
```

#### **7.2.2.2 添加系统调用**

由于此次实验是基于实验6实现的，故需要在实验6修改后的Linux0.11内核中进行进一步修改。

* 将shm.c放入 linux-0.11/kernel 路径下；
* 修改linux-0.11/include/unistd.h文件，即为新添加的2个系统调用设置编号；
```
#define __NR_shmget 76
#define __NR_shmat 77
```
* 修改sys.h文件，将2个新的系统调用加入到sys_call_table中；
```
extern int sys_shmget();
extern int sys_shmat();

fn_ptr sys_call_table[] = {...,sys_shmget, sys_shmat };
```
* 修改linux-0.11/kernel/system_call.s文件，将记录系统调用数的nr_system_calls变量改为78；
```
nr_system_calls = 78
```
* 修改linux-0.11/kernel/Makefile文件，加入对shm.c文件的编译；
```
OBJS  = ... shm.o
shm.s shm.o: shm.c ../include/linux/kernel.h ../include/linux/sched.h \
  ../include/linux/mm.h ../include/unistd.h
```

#### **7.2.2.3 编写生产者和消费者程序**

producer.c和consumer.c的实现与实验6的pc.c十分相似，只需将pc.c中生产者部分单独实现，消费者部分单独实现，然后将产品存入文件改为存入共享内存，读取产品从文件改为从共享内存即可，具体实现见code/producer.c和code/consumer.c。生产者和消费者伪代码如下。
```
/* producer */
int main()
{
    打开信号量mutex，empty，full
	shmid = shmget(1234, BUFSIZE);
    if shmid为-1
        报错并返回
    p = (int*) shmat(shmid);
    for( i = 0 ; i < NUMBER; i++) {
        生产
        sem_wait(empty);
        sem_wait(mutex);
        在p中写入产品
        sem_post(full);
        sem_post(mutex);
    }
    释放信号量mutex，empty，full
    return 0;
}

/* consumer */
int main()
{
    打开信号量mutex，empty，full
	shmid = shmget(1234, BUFSIZE);
	if shmid为-1
        报错并返回
    p = (int *)shmat(shmid);
    for( i = 0; i < NUMBER; i++ ) {
        sem_wait(full);
        sem_wait(mutex);
        从p中读出产品
        sem_post(empty);
        sem_post(mutex);
        消费
    }
    释放信号量mutex，empty，full
    return 0;
}
```
#### **7.2.2.4 编译并测试**

```
/* 编译内核 */
cd ./linux-0.11
make all
/* 挂载文件 */
cd ..
./mount-hdc
cp unistd.h ./hdc/usr/include/
cp sem.h ./hdc/usr/include/linux
cp producer.c ./hdc/usr/root/
cp consumer.c ./hdc/usr/root/
/* 在Linux0.11中编译并运行程序 */
gcc -o producer producer.c
gcc -o consumer consumer.c
./producer > p.txt & ./consumer > c.txt
```

得到的运行结果如图14所示，可以看到两个程序共享一页0x00fa5000。再查看p.txt以及c.txt可以了解生产者和消费者的详细活动情况，如图15、16。p.txt记录了shmid以及生产者写入缓存的记录；c.txt记录了shmid，消费者读缓存记录以及消费产品的记录。

<div align="center"><img src="images/14.png"><br>Figure 14. 运行结果</div>
<div align="center"><img src="images/15.png"><br>Figure 15. 生产者活动</div>
<div align="center"><img src="images/16.png"><br>Figure 16. 消费者活动</div>

## 7.3 实验问题

### 7.3.1 对于地址映射实验部分，列出你认为最重要的那几步（不超过4步），并给出你获得的实验数据。

1. 调试得到循环体的汇编代码，进而确定i的逻辑地址，即ds:0x00003004；
2. 通过gdt、ldt查找ds段描述符，进而将逻辑地址转化为线性地址，为0x10003004；
3. 查找页表，将线性地址转化为物理地址，为0x00fa7004。

### 7.3.2 test.c退出后，如果马上再运行一次，并再进行地址跟踪，你发现有哪些异同？为什么？

相同点：程序再次进入死循环，无法结束。因为再次运行时，相当于另起了一个进程，i的值又不为0了。此外，在跟踪地址时，发现逻辑地址、线性地址仍然是相同的，原因应该是始终只有test一个程序在运行，故线性空间中分配的段基地址相同，而逻辑地址在程序编译后就定好了，故最终逻辑地址和线性地址一致。

不同点：物理分页发生了改变，所以物理地址也变了，如图17所示物理页号已经发生了改变。这是因为两次运行前后，物理内存空间已经发生了变化，所以操作系统会根据实际情况按照特定策略分配不同位置的物理内存。

这里我额外做了一个实验，将hello程序和test程序同时运行，结果发现ds描述符中的线性基地址内容发生了改变，如图18，变为了0x14000000。这说明线性地址也是可能改变的。

<div align="center"><img src="images/17.png"><br>Figure 17. 物理页号发生改变</div>
<div align="center"><img src="images/18.png"><br>Figure 18. test与hello同时运行</div>