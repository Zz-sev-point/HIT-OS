#define __LIBRARY__
#include <unistd.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/mm.h>
#include <errno.h>

#define SHM_SIZE 64

typedef struct shm_hs {
	unsigned int key;
	unsigned int size;
	unsigned long page;
}shm_ds;

static shm_ds shm_list[SHM_SIZE] = {{0, 0, 0}};

int sys_shmget(unsigned int key, size_t size) {
    int i;
    unsigned long page;
    /* key不可为初始值 */
    if (key == 0) {
        printk("shmget: key cannot be 0!\n");
        return -1;
    }
    /* size不可超过一页大小 */
    if (size > PAGE_SIZE){
        printk("shmget: size %u is greater than the page size %ud!\n", size, PAGE_SIZE);
        errno = ENOMEM;
        return -1;
    }
    for (i = 0; i < SHM_SIZE; i++) {
        if (shm_list[i].key == key)
            return i;
    }
    if (!(page = get_free_page())) {
        printk("shmget: no more space!\n");
        errno = ENOMEM;
        return -1;
    }
    printk("shmget get memory's address is 0x%08x\n", page);
    for (i = 0; i < SHM_SIZE; i++) {
        if (shm_list[i].key == 0) {
            shm_list[i].key = key;
            shm_list[i].size = size;
            shm_list[i].page = page;
            return i;
        }
    }
    printk("shmget: shm_list is full!\n");
    return -1;
}

void *sys_shmat(int shmid) {
    unsigned long data_base_addr, brk;
    /* shmid不可越界，且shm_list[shmid]有意义 */
    if (shmid < 0 || SHM_SIZE <= shmid || shm_list[shmid].page == 0 || shm_list[shmid].key <= 0) {
        errno = EINVAL;
        return -1;
    }
    /* 获取brk */
    data_base_addr = get_base(current->ldt[2]);
    printk("current's data_base_addr = 0x%08x,new page = 0x%08x\n", data_base_addr, shm_list[shmid].page);
    brk = current->brk + data_base_addr;
    current->brk += PAGE_SIZE;
    if (put_page(shm_list[shmid].page, brk) == 0){
        errno = ENOMEM;
        return -1;
    }
    return (void *)(current->brk - PAGE_SIZE);
}