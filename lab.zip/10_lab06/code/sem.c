#include <linux/sem.h>
#include <linux/sched.h>
#include <unistd.h>
#include <asm/segment.h>
#include <linux/tty.h>
#include <linux/kernel.h>
#include <linux/fdreg.h>
#include <asm/system.h>
#include <asm/io.h>
//#include <string.h>

sem_t semtable[SEMTABLE_LEN];

sem_t *sys_sem_open(const char *name,unsigned int value) {
    char tmp_name[30];
    int flag = 0;
    int i=0;
    int name_len=0;
    int new_sem = -1;
    while (get_fs_byte(name+name_len) != '\0' && name_len < 29)
        name_len++;
    if (name_len > SEM_NAME_LEN) {
        printk("Semaphore name is too long!");
        return NULL;
    }
    for (i=0; i<name_len; i++)
        tmp_name[i]=get_fs_byte(name+i);
    int sem_name_len =0;
    sem_t *p=NULL;
    /* 查找信号量 */
    for(i=0;i<SEMTABLE_LEN;i++) {
        if (semtable[i].busy == 1) {
            sem_name_len = strlen(semtable[i].name);
            if(sem_name_len == name_len) {
                if(!strcmp(tmp_name,semtable[i].name)) {
                    flag = 1;
                    break;
                }
            }
        }
    }
    /* 信号量存在 */
    if(flag == 1) 
        p=(sem_t*)(&semtable[i]);
    /* 信号量不存在，则新建*/
    else {
        for(i=0; i<SEMTABLE_LEN; i++) {
            if (semtable[i].busy == 0) {
                new_sem = i;
                break;
            }
        }
        if(new_sem == -1) {
            printk("No more semaphores!");
            return NULL;
        }
        for(i=0; i<name_len; i++)
            semtable[new_sem].name[i]=tmp_name[i];
        semtable[new_sem].value = value;
        semtable[new_sem].busy = 1;
        p=(sem_t*)(&semtable[new_sem]);
    }
    return p;
}


int sys_sem_wait(sem_t *sem) {
    cli();
    while(sem->value <= 0)
        sleep_on(&(sem->queue));
    sem->value--;
    sti();
    return 0;
}
int sys_sem_post(sem_t *sem) {
    cli();
    sem->value++;
    if((sem->value) <= 1)
        wake_up(&(sem->queue));
    sti();
    return 0;
}

int sys_sem_unlink(const char *name) {
    char tmp_name[30];  
    int flag = 0;
    int i=0;
    int name_len=0;
    int tar_sem;
    while(get_fs_byte(name+name_len) != '\0' && name_len < 29)
            name_len++;
    if(name_len>SEM_NAME_LEN)
        return NULL;
    for(i=0;i<name_len;i++)
        tmp_name[i]=get_fs_byte(name+i);
    int sem_name_len =0;
    /* 查找信号量 */
    for(i=0;i<SEMTABLE_LEN;i++) {
        if (semtable[i].busy == 1) {
            sem_name_len = strlen(semtable[i].name);
            if(sem_name_len == name_len) {
                if(!strcmp(tmp_name,semtable[i].name)) {
                    flag = 1;
                    tar_sem = i;
                    break;
                }
            }
        }
    }
    /* 删除信号量 */
    if(flag == 1) {
        semtable[tar_sem].busy = 0;
        return 0;
    }
    else
        return -1;
}