#define __LIBRARY__
#include <unistd.h>
#include <linux/sem.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/sched.h>

_syscall2(sem_t *,sem_open,const char *,name,unsigned int,value)
_syscall1(int,sem_wait,sem_t *,sem)
_syscall1(int,sem_post,sem_t *,sem)
_syscall1(int,sem_unlink,const char *,name)

const char *FILENAME = "/usr/root/buffer_file"; /* 存放产品的缓冲文件路径 */
const int CONSUMER_AMT = 5;                     /* 消费者数量 */
const int PRODUCT_AMT = 500;                    /* 产品总量 */
const int BUFFER_SIZE = 10;                     /* 缓冲区大小 */
sem_t *metux, *full, *empty;                    /* 信号量 */
unsigned int pro_no, con_no;                    /* 刚生产/消费的产品号 */
int fi, fo;                                     /* 供生产者写入或消费者读取的缓冲文件句柄 */

int main(int argc, char *argv[])
{
    char *filename;
    int pid;
    int i;

    filename = argc > 1 ? argv[1] : FILENAME;
    fi = open(filename, O_CREAT| O_TRUNC| O_WRONLY, 0222);    /* 生产者只写 */
    fo = open(filename, O_TRUNC| O_RDONLY, 0444);            /* 消费者只读 */

    metux = sem_open("METUX", 1);       /* 互斥信号量，防止生产消费同时进行 */
    full = sem_open("FULL", 0);         /* 产品剩余信号量，大于0才可消费 */
    empty = sem_open("EMPTY", BUFFER_SIZE);    /* 空信号量，大于0才可生产 */

    pro_no = 0;

    if ((pid = fork())) {   /* 生产者 */
        while (pro_no < PRODUCT_AMT) {    /* 是否生产完所有产品 */
            pro_no++;
            sem_wait(empty);
            sem_wait(metux);

            /* 生产完BUFFER_SIZE件产品后，将缓冲文件的读头重新定位到文件首部 */
            if(!(pro_no % BUFFER_SIZE))
                lseek(fi, 0, 0);
            write(fi, (char *) &pro_no, sizeof(pro_no));        /* 写入产品编号 */
            printf("pid %d:\tproduces item %d\n", pid, pro_no);
            fflush(stdout); 

            sem_post(full);
            sem_post(metux);
        }
    }
    else {    /* 消费者 */
        i = CONSUMER_AMT;
        while(i--) {     /* 创建iCONSUMER_AMT个消费者 */
            if(!(pid=fork())) {
                pid = getpid();
                while(1) {
                    sem_wait(full);
                    sem_wait(metux);

                    /* read()读到文件末尾时返回0，将文件的位置指针重新定位到文件首部 */
                    if(!read(fo, (char *)&con_no, sizeof(con_no))) {
                        lseek(fo, 0, 0);
                        read(fo, (char *)&con_no, sizeof(con_no));
                    }
                    printf("pid %d: consumes item %d\n", pid, con_no);
                    fflush(stdout);

                    /* printf("%d: %d\n", pid, con_no);
                    fflush(stdout); */

                    sem_post(empty);
                    sem_post(metux);

                    if(con_no == PRODUCT_AMT) {   /* 若已消费完所有商品，则结束 */
                        close(fi);
                        close(fo);
                        return 0;
                    }
                }
            }
        }
    }
}