# 6. 信号量的实现和应用

## 6.1 实验目的
* 加深对进程同步与互斥概念的认识；
* 掌握信号量的使用，并应用它解决生产者——消费者问题；
* 掌握信号量的实现原理。

## 6.2 实验内容

### 6.2.1 信号量的实现

本次实验实现了以下4个系统调用：
```
sem_t *sem_open(const char *name, unsigned int value);
int sem_wait(sem_t *sem);
int sem_post(sem_t *sem);
int sem_unlink(const char *name);
```
其中sem_t为自定义的信号量类型，其数据结构如下。其中name为信号量ID，value为信号量值，busy表示信号量是否被使用，queue为记录信号量的队列。
```
typedef struct semaphore{
    char name[SEM_NAME_LEN];
    int value;
    int busy;
    struct task_struct *queue;
} sem_t;
extern sem_t semtable[SEMTABLE_LEN];
```
接下来分别介绍4个系统调用的实现，具体代码见code/sem.c和code/sem.h。

#### 6.2.1.1 sem_open()

sem_open()的功能是创建一个信号量或打开一个已经存在的信号量，实现的伪代码如下。首先，由于信号量ID的长度是有限的，需要判断name长度是否大于限长，若大于则必不可能存在目标信号量，直接报错返回NULL。小于时，则读入name，并在semtable（一个存储一系列信号量的数组）中遍历查找目标，查找到的条件是信号量ID等于name且信号量busy位为1，找到则返回该信号量，否则新建一个信号量并返回之，若semtable已满则报错返回NULL。
```
sem_t *sys_sem_open(const char *name,unsigned int value) {
    计算name长度
    if name长度>限长 then
        报错并返回NULL
    读入name
    for (i=0;i<SEMTABLE_LEN;i++) 
        查找ID为name的信号量
    if 信号量存在
        将该信号量赋值给p
    else {
        for(i=0; i<SEMTABLE_LEN; i++) {
            if semtable已满
                报错并返回NULL
            查找semtable中一个空闲信号量并赋给p
        }
        初始化p
    }
    返回p;
}
```
#### 6.2.1.2 sem_wait()
sem_wait()为信号量的P原子操作，若不满足继续运行的条件，则令进程在信号量sem上等待。利用cli()关中断和sti()开中断来实现原子操作，利用sleep_on()实现进程的等待，并且需要将信号量的值减1。
```
int sys_sem_wait(sem_t *sem) {
    cli();
    while(sem->value <= 0)
        sleep_on(&(sem->queue)); 
    sem->value--;
    sti();
    return 0;
}
```

#### 6.2.1.3 sem_post()
sem_wait()为信号量的V原子操作，若存在等待的进程，则唤醒其中一个等待进程。利用cli()关中断和sti()开中断来实现原子操作，利用wake_up()实现进程的唤醒，并且需要将信号量的值加1。
```
int sys_sem_post(sem_t *sem) {
    cli();
    sem->value++;
    if((sem->value) <= 1)
        wake_up(&(sem->queue));
    sti();
    return 0;
}
```

#### 6.2.1.4 sem_unlink()
sem_unlink()的功能是删除ID为name的信号量，删除成功返回0，失败返回-1，实现的伪代码如下。与sem_open类似，需要先判断name长度是否合法，然后遍历查找目标信号量，找到则将信号量busy位置0以示删除，否则返回-1。
```
int sys_sem_unlink(const char *name) {
    
    for (i=0;i<SEMTABLE_LEN;i++) 
        查找ID为name的信号量
    if 信号量存在
        将该信号量赋值给p
    else {
        for(i=0; i<SEMTABLE_LEN; i++) {
            if semtable已满
                报错并返回NULL
            查找semtable中一个空闲信号量并赋给p
        }
        初始化p
    }
    返回p;
    计算name长度
    if name长度>限长 then
        报错并返回-1
    读入name
    for(i=0;i<SEMTABLE_LEN;i++) {
        在semtable中查找目标信号量
    }
    if 找到目标信号量 
        该信号量busy位置0并返回0
    else
        返回-1
}
```
### 6.2.2 添加系统调用

添加系统调用的方式参考实验4，具体步骤如下：

* 将sem.c放入 linux-0.11/kernel 路径下，将sem.h放入 linux-0.11/include/linux 路径下；
* 修改linux-0.11/include/unistd.h文件，即为新添加的4个系统调用设置编号；
```
#define __NR_sem_open 72
#define __NR_sem_wait 73
#define __NR_sem_post 74
#define __NR_sem_unlink 75
```
* 修改sys.h文件，将4个新的系统调用加入到sys_call_table中；
```
extern int sys_sem_open();
extern int sys_sem_wait();
extern int sys_sem_post();
extern int sys_sem_unlink();

fn_ptr sys_call_table[] = {...,sys_sem_open, sys_sem_wait, sys_sem_post, sys_sem_unlink };
```
* 修改linux-0.11/kernel/system_call.s文件，将记录系统调用数的nr_system_calls变量改为76；
```
nr_system_calls = 76
```
* 修改linux-0.11/kernel/Makefile文件，加入对sem.c文件的编译；
```
OBJS  = ... sem.o
sem.s sem.o: sem.c ../include/linux/kernel.h ../include/unistd.h \
  ../include/linux/sem.h ../include/linux/sched.h
```

### 6.2.3 编写应用程序pc.c

应用程序pc.c的伪代码实现如下，具体代码实现见code/pc.c。
```
const char *FILENAME = "/usr/root/buffer_file"; 
const int CONSUMER_AMT = 5;
const int PRODUCT_AMT = 500;
const int BUFFER_SIZE = 10;
sem_t *metux, *full, *empty;
unsigned int pro_no, con_no;
int fi, fo; 

int main(int argc, char *argv[])
{
    初始化fi，fo文件句柄
    初始化信号量metux，full，empty
    pro_no = 0;

    /* 生产 */
    if ((pid = fork())) {
        while 未生产完所有产品 {
            生产产品
            sem_wait(empty);
            sem_wait(metux);
            放入缓冲区
            sem_post(full);
            sem_post(metux);
        }
    }

    /* 消费 */
    else {
        while 消费者未满CONSUMER_AMT个 {
            if(!(pid=fork())) {
                while(1) {
                    sem_wait(full);
                    sem_wait(metux);
                    从缓冲区读入
                    sem_post(empty);
                    sem_post(metux);
                    消费

                    if 已消费完所有商品
                        关闭fi，fo并返回
                }
            }
        }
    }
}
```

#### 6.2.3.1 变量解释
* FILENAME为缓存文件的路径；
* CONSUMER_AMT确定消费者数量；
* PRODUCT_AMT却sing产品总量，该实验规定为500；
* BUFFER_SIZE规定缓冲区大小，该实验规定为10；
* metux为互斥信号量，用于确保生产和消费不会同时进行，故初始值为1；
* full为产品剩余信号，大于0时说明可消费，初始值为0表示没有产品；
* empty为产品可生产信号，大于0时可消费，由于缓冲区大小为10，故初始值为10表示当前可至多生产10件产品；
* pro_no记录当前生产的产品编号，con_no记录当前消费的产品编号；
* fi和fo分别是生产者写入和消费者读出所用的文件句柄。

#### 6.2.3.2 函数体解释
由父进程担任生产者，在第一个while循环体中执行Producer的内容。本程序的“产品”为实数1-500,产品编号本身，故生产的实现即"pro_no++"。此外，由于缓冲区大小限定为10，故生产者每写入10个数，就需要利用lseek()将读头重新移到文件的第一位，实现如下。
```
if(!(pro_no % BUFFER_SIZE))
    lseek(fi, 0, 0);
write(fi, (char *) &pro_no, sizeof(pro_no));
```

由子进程担任消费者，在第二个while循环体中执行Consumerd的内容。由于本应用仅是读出实数而不进行任何操作，故没有实质的代码对应消费。同样因为缓冲区大小为10，故当消费者读到文件末尾时，就需要把读头重新移到文件第一位，实现如下。
```
if(!read(fo, (char *)&con_no, sizeof(con_no))) {
    lseek(fo, 0, 0);
    read(fo, (char *)&con_no, sizeof(con_no));
}
```

这里要注意的是，由于有多个消费者，故每个消费者并不知道之前是否消费满了10件产品，故只能通过读头是否已经到达文件末尾判断是否移动读头。

此外，为确保每次读出缓存后，读出信息能立刻打印到屏幕，在printf后添加一句"fflush(stdout);"来清空标准输出缓存。


### 6.2.4 编译并测试

由于此次在内核中添加了头文件sem.h，而编译并在bochs中运行linux0.11后，sem.h并不在/usr/include/linux中，故需要通过挂载放入。编译测试流程如下。
```
/* 编译内核 */
cd ./linux-0.11
make all
/* 挂载文件 */
cd ..
./mount-hdc
cp unistd.h ./hdc/usr/include/
cp sem.h ./hdc/usr/include/linux
cp pc.c ./hdc/usr/root/
/* 在Linux0.11中编译并运行程序 */
gcc -o pc pc.c
./pc
```

得到的运行结果如图1所示。

<div align="center"><img src="images/1.png"><br>Figure 1. 消费记录</div>

在生产时也添加打印信息，可以更清楚地看到整个生产消费的过程，如图2所示。可以发现由于缓冲区的限制，生产者一次最多只能生产10件产品。

<div align="center"><img src="images/2.png"><br>Figure 2. 生产消费记录</div>

## 6.3 实验问题

### **6.3.1 在pc.c中去掉所有与信号量有关的代码，再运行程序，执行效果有变化吗？为什么会这样？**

有变化，如图3即为其中的一种情况，可以发现491-500号产品被重复消费，原因是由于没有信号量来控制进程的生产和消费，生产者在生产了超过10个产品时，便会在缓冲文件中覆盖之前的产品，这里可能是生产者先生产完了所有产品，导致只有最后10个留在缓冲区中。然后后面的消费者由于没有信号量也不知道其他人是否消费了某一产品，故都重复消费了491-500产品。

此外，也可能存在生产者还未生产，消费者即从缓冲区读入消费的情况。

<div align="center"><img src="images/3.png"><br>Figure 3. 生产消费记录</div>

### **6.3.2 实验的设计者按如下程序编写可行吗？如果可行，那么它和标准解法在执行效果上会有什么不同？如果不可行，那么它有什么问题使它不可行？**
```
Producer()
{
    P(Mutex);  //互斥信号量
    // 生产一个产品item;
    P(Empty);  //空闲缓存资源
    // 将item放到空闲缓存中;
    V(Full);  //产品资源
    V(Mutex);
}

Consumer()
{
    P(Mutex);
    P(Full);
    // 从缓存区取出一个赋值给item;
    V(Empty);
    // 消费产品item;
    V(Mutex);
}
```

不可行。若出现Empty=10, Full=0的情况，则接下来无论生产者还是消费者，在执行到P(Empty)/P(Full)都会进入等待状态，而此时它已经占用了mutex，导致其他进程也无法运行，整个程序就进入了死锁的状态。