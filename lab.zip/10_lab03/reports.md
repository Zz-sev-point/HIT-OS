# 3. 操作系统的引导

## 3.1 实验目的
* 熟悉实验环境；
* 建立对操作系统引导过程的深入认识；
* 掌握操作系统的基本开发过程；
* 能对操作系统代码进行简单的控制，揭开操作系统的神秘面纱。

## 3.2 实验内容

### **3.2.1 改写bootsect.s**

bootsect是磁盘引导程序，ROM BIOS会把该程序加载到0x7c00处并执行之。首先，该程序会将自身移到0x90000处，代码实现如下：

```
_start:
    mov	$BOOTSEG, %ax
	mov	%ax, %ds				# set ds
	mov	$INITSEG, %ax
	mov	%ax, %es				# set es
	mov	$256, %cx				# move 256
	sub	%si, %si				# move from ds:si
	sub	%di, %di				# move to es:di
	rep	
	movsw
	ljmp	$INITSEG, $go
go:	mov	%cs, %ax				# set ds, es, ss
	mov	%ax, %ds
	mov	%ax, %es
# put stack at 0x9ff00.
	mov	%ax, %ss
	mov	$0xFF00, %sp		# arbitrary value >>512

```

然后，该程序会将setup加载到0x90200处，代码实现如下：
```
load_setup:
	mov	$0x0000, %dx		# drive 0, head 0
	mov	$0x0002, %cx		# sector 2, track 0
	mov	$0x0200, %bx		# address = 512, in INITSEG
	.equ    AX, 0x0200+SETUPLEN
	mov     $AX, %ax		# service 2, nr of sectors
	int	$0x13			# read it
	jnc	ok_load_setup		# ok - continue
	mov	$0x0000, %dx
	mov	$0x0000, %ax		# reset the diskette
	int	$0x13
	jmp	load_setup
```

接着，该程序会在屏幕打印提示信息。在linux0.11中，会自动打印“Loading system ...”，这里根据改写要求使程序打印“Zinux is booting...”。打印的实现方式参考了linux0.11中打印提示信息的方法，利用0x10中断进行实现，主要是修改了传递给中断程序的打印字符串长度（通过cx传递）和字符串的内容（msg1），具体代码如下。其中，第一次调用中断程序时，ah设为0x03，用于获取当前光标位置，第二次调用中断程序时，ah设为0x13，用于打印bp存储的地址对应的字符串内容。
```
# Print some inane message

	mov	$0x03, %ah		# read cursor pos
	xor	%bh, %bh
	int	$0x10
	
	mov	$26, %cx
	mov	$0x0007, %bx		# page 0, attribute 7 (normal)
	#lea	msg1, %bp
	mov     $msg1, %bp
	mov	$0x1301, %ax		# write string, move cursor
	int	$0x10

msg1:
	.byte 13,10
	.ascii "Zinux is booting..."
	.byte 13,10,13,10
```
最后，该程序执行一条ljmp指令跳转去执行setup程序。

在实现bootsect程序并编译运行后，可以得到下图结果。

<div align="center"><img src="images/bootsect.png"><br>Figure 3-1. bootsect.s打印信息</div>

### **3.2.2 改写setup.s**

进入setup后，首先需要打印提示信息“Now we are in SETUP”，该实现与bootsect中打印提示信息的实现相似，具体代码如下。其中，需要对ds和es进行修改以帮助处理器找到目标字符串的存储位置。
```
_start:
	mov %cs, %ax
	mov %ax, %ds
	mov %ax, %es
	
    mov	$0x03, %ah		# read cursor pos
	xor	%bh, %bh
	int	$0x10
	mov	$25, %cx
	mov	$0x0007, %bx		# page 0, attribute 7 (normal)
	mov     $msg1, %bp
	mov	$0x1301, %ax		# write string, move cursor
	int	$0x10
msg1:
    .byte 13,10
    .ascii "Now we are in SETUP"
    .byte 13,10,13,10
```

然后，setup会获取硬件参数并从内存的0x90000处开始存放。在Linux0.11中，setup程序保存了光标位置、内存大小、显存大小、显卡信息、第一和第二硬盘信息。仿照Linux0.11，本程序用ah=0x03调用0x10中断读取光标位置，用ah=0x88调用0x15中断读取内存大小，用ah=0x0f调用0x10中断获取显卡参数，并在0x41中断向量的位置读取第一个硬盘的参数信息。
```
# ok, the read went well so we get current cursor position and save it for posterity.

	mov	$INITSEG, %ax	
	mov	%ax, %ds
	mov	$0x03, %ah	# read cursor pos
	xor	%bh, %bh
	int	$0x10		# save it in known place, con_init fetches
	mov	%dx, %ds:0	# it from 0x90000.

# Get memory size (extended mem, kB)

	mov	$0x88, %ah 
	int	$0x15
	mov	%ax, %ds:2

# Get video-card data:

	mov	$0x0f, %ah
	int	$0x10
	mov	%bx, %ds:4	# bh = display page
	mov	%ax, %ds:6	# al = video mode, ah = window width

# Get hd0 data

	mov	$0x0000, %ax
	mov	%ax, %ds
	lds	%ds:4*0x41, %si
	mov	$INITSEG, %ax
	mov	%ax, %es
	mov	$0x0080, %di
	mov	$0x10, %cx
	rep
	movsb
```
最后，setup程序需要打印上述内容，打印的实现方式参考了指导教程的内容，即通过一个循环，以16进制逐字打印，其中由于小写字母的ascii码并不紧接在数字“9”之后，故对于大于10的16进制数还需要额外的加7处理。由于显卡参数中的模式和窗口宽度只有两个字节而非四个，故打印函数的参数添加了打印长度并通过寄存器bx进行传递，实际就是利用bx设置cx从而控制函数循环的次数。
```
print_hex:
	mov %bx, %cx	# loop time
	mov %ax, %dx
print_digit:
	rol $4, %dx
	mov $0xe0f, %ax
	and %dl, %al
	add $0x30, %al
	cmp $0x3a, %al
	jl outp
	add $0x07, %al
outp:
	int $0x10
	loop print_digit
	ret

print_nl:
	mov $0xe0d, %ax
	int $0x10
	mov $0x0a, %al
	int $0x10
	ret
```
打印硬盘参数时，需要确定各个参数的偏移位置。根据指导书给出的提示，柱面数偏移量为0x0，磁头数偏移量为0x2，每磁道扇区数偏移量为0xe。打印显卡参数时，参考了linux0.11所给的注释，低两位字节存储video mode，高两位字节存储window width。

### **3.2.4 修改build.sh**

build文件主要是将bootsect、setup和system三个文件按序写入Image中，此次实验只实现了前两个文件，故将第三个文件的写入部分代码注释掉即可。

最后，编译并运行Image,得到如下结果。

<div align="center"><img src="images/result.png"><br>Figure 3-2. 运行结果</div>

### **3.2.3 软件必须遵循的“多此一举”的步骤**

1. 计算机上电后，操作系统首先不会被加载到内存0x0000处，如Linux0.00就是将head加载到0x10000处，再移到0x0000处，Linux0.11加载system亦是如此，这种移动是多余的。

* **原因**：BIOS会在0x0000处初始化中断向量表，而加载操作系统需要调用其中的中断处理程序，如果直接加载到0x0000处会覆盖中断向量表，则加载过程中如果需要调用中断则会出现问题。

* **解决方案**：由于中断向量表的大小是固定的，可以为其单独开辟一块空间，BIOS每次将中断向量表初始化在特定空间，可以是内存的某一块空间，如内存的末尾，也可以是一组寄存器，这样操作系统就可以直接加载到0x0000处。

2. 计算机上电后，BIOS会将启动设备的第一个扇区（即引导扇区）读入内存地址0x7c00处并执行之（bootsect）。然后，该程序会先将自己移到相对靠后的内存空间中，再加载主模块，这种移动是多余的。

* **原因**：bootsect后移是为了防止被加载的主模块覆盖。

* **解决方案**：扩大实模式下可访问的地址空间，直接将bootsect加载到内存靠后的位置，这样就可省去后移的操作。

