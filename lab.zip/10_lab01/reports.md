# 1. 调试分析 Linux 0.00 引导程序

## 1.1 实验目的
* 熟悉实验环境；
* 掌握如何手写Bochs虚拟机的配置文件；
* 掌握Bochs虚拟机的调试技巧；
* 掌握操作系统启动的步骤。

## 1.2 实验内容

本实验对Linux 0.00引导程序进行了调试和跟踪。

### **1.2.1 head.s工作原理**

head.s主要包括初始化、时钟中断处理、系统调用中断处理、Task0和Task1五个部分:

* **初始化：** 先初始化了GDT和IDT，并设置了8253定时芯片，然后将IDT的第8和128项分别置为时钟中断门描述符和系统调用陷阱门描述符，最后通过手动压栈的方式建立中断返回的场景，利用IRET指令跳转到Task0代码段开始执行任务。其中最后在手动压栈前需要**初始化TR和LDTR并开中断（boot.s中关了中断）**，利用IRET指令实现跳转是因为初始化部分属于内核代码，特权级为0，而接下来任务的执行特权级为3，需要以上述方式实现特权级的转换。
  
*  **时钟中断处理：** 图1-1展示了处理程序的内容。首先让数据段寄存器DS指向内核数据段，因为需要用到内核的数据变量current判断当前正在执行Task0还是Task1，然后根据该值切换到另一个任务来执行。**需要注意的是**，程序调用ljmp指令进行跳转，操作数为TSS0或TSS1的选择子，该指令执行过程中，会利用对应段描述符更新CS, DS, ES, SS, FS, GS等段寄存器实现环境和特权级转换，从而实现任务切换（如图1-0），而任务切换时，原任务会停留在切换前的位置，所以任务0切换到任务1后，任务0停留在内核态"ljmp $TSS1_SEL, $0"处，在任务1在切换回任务0时，任务0执行下一句"jmp 2f"最终从内核态返回然后继续打印字符，任务1切换任务0同理。
<div align="center"><img src="images/ER0.png"> <img src="images/ER3.png"><br>Figure 1-0. 任务切换前后各个段寄存器</div>

<div align="center"><img src="images/timer_interrupt.png"><br>Figure 1-0. 时钟中断处理</div>

*  **系统调用中断：** 首先将DS以及edx、ecx、ebx、eax四个通用寄存器压栈以保存寄存器状态，然后让DS指向内核数据段并调用内核程序write_char打印字符到屏幕，最后弹栈恢复寄存器状态并返回。
  
*  **Task0和Task1：** 首先让DS指向本任务的局部数据段（尽管并没有使用局部数据），并将“A”或“B”的ASCII码放入AL寄存器，利用INT指令实现系统调用中断来打印字符，最后执行一个循环实现时延再返回程序第一条指令重复执行，知道出现发生时钟中断。

### **1.2.2 head.s内存分布情况**

**1）GDT & IDT**

初始化完GDT和IDT后，通过查看GDTR和IDTR可以得到两者的地址（如图1-2），分别为0x998和0x198。通过查看初始化程序可知，IDT空间有256个8字节的门描述符。紧接其后的就是GDT，GDT的内容如图1-3所示，有8个描述符。第一个为空描述符（选择符0x0，在读书笔记中有提到过），接下来分别是内核代码段描述符(0x08)、内核数据段描述符(0x10)、显示内存段描述符(0x18)、TSS0段描述符(0x20)、LDT0段描述符(0x28)、TSS1段描述符(0x30)、LDT1段描述符(0x38)。

<div align="center"><img src="images/gdtr_idtr.png"><br>Figure 1-2. GDTR & IDTR</div>

<div align="center"><img src="images/gdt.png"><br>Figure 1-3. GDT</div>

**2）内核**

通过上述GDT可得内核代码段和数据段描述符分别为0x00c0_9a00_0000_07ff和0x00c0_9200_0000_07ff。通过查阅手册可知，代码段和数据段基地址均为0x0，段限长均为0x7ff字节。对于内核的堆栈，程序的第三条指令初始化栈指针esp为0xbd8，即栈底为0xbd8。查看内存空间发现0xbd8至GDT末位均未使用作为栈空间，故栈顶上限为0x9d8。

<div align="center"><img src="images/stack.png"><br>Figure 1-4. 栈顶上限</div>

**3） Task0**

通过上述GDT可得TSS0和LDT0段基地址分别为0xbf8和0xbe0，段限长分别为0x68和0x40字节。

查看LDT0，内有3个描述符，分别为空描述符(0x0)、局部代码段描述符(0x0f)、局部数据段描述符(0x17)。后两者分别为0x00c0_fa00_0000_03ff和0x00c0_f200_0000_03ff，由此可得局部代码段和数据段的基地址都为0x0。在首次内核进入任务0时，IRET前的压栈操作中压入了任务0首代码的偏移值，如图1-5所示，为0x10e0。

图1-5压的数据/堆栈指针为0xbd8，由于数据/堆栈段基地址为0x0，故用户栈栈底地址为0xbd8。

此外，在TSS0后还有128*4字节的任务0的内核栈空间，通过跟踪任务0执行INT指令进入内核态可知栈底为0xe4c（图1-6）。

<div align="center"><img src="images/task0_code.png"><br>Figure 1-5. Task0代码偏移量</div>

<div align="center"><img src="images/t0_stack0.png"><br>Figure 1-6. Task0内核栈</div>

**4） Task1**

通过上述GDT可得TSS1和LDT1段基地址分别为0xe78和0xe60，段限长分别为0x68和0x40字节。

查看LDT0，内有3个描述符，分别为空描述符(0x0)、局部代码段描述符(0x0f)、局部数据段描述符(0x17)。后两者分别为0x00c0_fa00_0000_03ff和0x00c0_f200_0000_03ff，由此可得局部代码段和数据段的基地址都为0x0。这里通过在时钟中断处理程序中逐步调试直至跳转到任务1来确定代码段首地址，如图1-7所示，为0x10f4。

通过跟踪程序进入任务2，查看esp可知，任务2用户栈栈底地址为0x1308。

此外，在TSS1后还有128*4字节的任务1的内核栈空间，通过跟踪任务1执行INT指令进入内核态可知栈底为0x10cc（图1-8）。

<div align="center"><img src="images/task1_code.png"><br>Figure 1-7. Task1代码偏移量</div>

<div align="center"><img src="images/t1_stack0.png"><br>Figure 1-8. Task1内核栈</div>

### **1.2.3 head.s的57-62行分析**

<div align="center"><img src="images/57_62.png"><br>Figure 1-9. 57-62行代码</div>

如图1-9所示为57-62行代码在内存中的形式，这里进行的压栈操作是为了手动建立中断返回任务0的场景。程序将任务0的局部数据段选择子、栈指针、EFLAGS、代码段选择子以及代码指针入栈，来构建一个好像是任务0调用了初始化程序，现在需要返回任务0的情景，而利用IRET来实现进入任务0主要是要实现特权级的转换，如图1-10所示，可以看到IRET执行前后，段寄存器发生了变化，存储的段选择符的DPL改变了，从而改变了特权级。

<div align="center"><img src="images/tot0b.png"> <img src="images/tot0a.png"><br>Figure 1-10. IRET执行前后各个段寄存器</div>

### **1.2.4 执行IRET后PC的确定**

<div align="center"><img src="images/TR_LDTR.png"><br>Figure 1-11. TR && LDTR</div>

图1-11显示的是51-54行的代码，即程序将TR和LDTR初始化为任务0的TSS和LDT段选择子，从而实现这两者的初始化，同时也为下面获得IRET后的PC做铺垫。

由图1-9可知，执行IRET前，已经将任务0的代码段选择子(0x0f)和代码指针(0x10e0)入栈，故处理器可通过段选择子在此时的LDT（LDTR中存的是LDTR0）中得到代码段的描述符，进而得到基地址，并与代码指针（即偏移量）相加即可得到最后的PC，为0x000010e0。

### **1.2.5 执行IRET后栈的变化**

<div align="center"><img src="images/IRET_stack_b.png"><br>Figure 1-12. 执行前的栈</div>

<div align="center"><img src="images/IRET_stack_a.png"><br>Figure 1-13. 执行后的栈</div>

有图1-12和1-13可知，执行前，栈内即是之前压入栈中用于中断返回的内容，执行后，这些内容均弹栈用于进入任务0，栈此时已空。

### **1.2.6 系统调用时栈的变化**

<div align="center"><img src="images/int_b
.png"><br>Figure 1-14. 执行INT前的栈</div>

<div align="center"><img src="images/int_d
.png"><br>Figure 1-15. 执行INT时的栈</div>

如图1-14所示，第一次进行任务0时，执行INT前，栈顶仍为0xbd8，栈为空。在执行INT时，转为了内核模式，栈指针指向了任务0的内核栈顶0xe4c，然后将DS, EDX, ECX, EBX, EAX进行压栈以保存寄存器状态，在执行完中断处理后，又将上述内容弹栈，最后返回任务0代码，进入用户态，栈指针再次指向0xbd8。

### **1.2.7 关于初始内核栈的讨论**

在刚执行完初始化GDT后发现内核栈空间最底字节为0x18而非0，这显然与我们认为的初始栈空间应全为0的认知不符。

在仔细跟踪后发现，此处原本为0x00，在初始化IDT后该处字节为0x13，在初始化GDT后有变为0x18。实际原因就是初始化IDT和GDT都利用CALL进行了跳转，于是就不可避免地要将返回地址压栈，显然初始化IDT后一条代码地址为0x13，初始化GDT后一条代码地址为0x18，而弹栈后原栈空间内容并不清0，仅改变esp，故就有了现在的情况。

<div align="center"><img src="images/set_idt
.png"><br>Figure 1-16. 初始化IDT后</div>

<div align="center"><img src="images/set_gdt
.png"><br>Figure 1-17. 初始化GDT后</div>