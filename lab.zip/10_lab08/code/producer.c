#define   __LIBRARY__
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <linux/sem.h>

_syscall2(sem_t*,sem_open,const char *,name,unsigned int,value);
_syscall1(int,sem_wait,sem_t*,sem);
_syscall1(int,sem_post,sem_t*,sem);
_syscall1(int,sem_unlink,const char *,name);
_syscall1(void*,shmat,int,shmid);
_syscall2(int,shmget,int,key,int,size);
_syscall3(int,debug_paging,pid_t,pid,void *,address,const char *,logPath)

#define NUMBER 500 /* 产品总数 */
#define BUFSIZE 10 /* 缓冲区大小 */

sem_t   *empty, *full, *mutex;
int main()
{
    int  i,shmid;
    int *p;
    int  buf_in = 0; /* 写入缓冲区位置 */
    /* 打开信号量 */
    if((mutex = sem_open("mutex",1)) == NULL) {
        perror("sem_open() error!\n");
        return -1;
    }
    if((empty = sem_open("empty",10)) == NULL) {
        perror("sem_open() error!\n");
        return -1;
    }
    if((full = sem_open("full",0)) == NULL) {
        perror("sem_open() error!\n");
        return -1;
    }
    /* 共享内存页 */
	shmid = shmget(1234, BUFSIZE);
	printf("shmid:%d\n",shmid);
    if(shmid == -1)
        return -1;
    p = (int*) shmat(shmid);
    debug_paging(getpid(), p, "/usr/var/paging.log");
    debug_paging(getpid(), NULL, "/usr/var/paging.log");
    /* 开始生产 */
	printf("producer start\n");
	fflush(stdout);
    for( i = 0 ; i < NUMBER; i++) {
	    fflush(stdout);
        sem_wait(empty);
        sem_wait(mutex);
        p[buf_in] = i;
        /*printf("producer write %d into buf %d\n", i, buf_in);
	    fflush(stdout);*/
        buf_in = ( buf_in + 1)% BUFSIZE;
        sem_post(full);
        sem_post(mutex);
    }
	printf("producer end\n");
	fflush(stdout);
    /* 释放信号量 */
    sem_unlink("full");
    sem_unlink("empty");
    sem_unlink("mutex");
    return 0;
}