#define __LIBRARY__
#include <unistd.h>
#include <linux/kernel.h>
#include <linux/sched.h>
#include <linux/mm.h>
#include <fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>

int sys_debug_paging(pid_t pid, void *address, const char *logPath) {
    int task_index = 0, flag = 0, table_addr_amt = 0;
    int table_indexes[16];
    int fp;
    unsigned long base_addr, linear_addr, dir_index, table_index, offset;
    unsigned long table_item1, table_item2;
    unsigned long table_addr, page_addr, phy_addr;
    unsigned long table_addrs[16];
    for (int i=0; i<NR_TASKS; i++) {
        if (task[i]->pid == pid) {
            task_index = i;
            flag = 1;
            break;
        }
    }
    if (flag == 0) {
        printk("No such pid!\n");
        return -1;
    }
    /* 段基地址 */
    base_addr = get_base(task[task_index]->ldt[2]);
    if (address != NULL && logPath == NULL) {
        printk("\nPid: %d  Task: %d  LinearBaseAddress: 0x%08x\n", pid, task_index, base_addr);
        /* 线性地址 */
        linear_addr = base_addr + ((unsigned long)address);
        dir_index = linear_addr >> 22;                  /* 31-22 */
        table_index = (linear_addr & 0x003fffff) >> 12; /* 21-12 */
        offset = linear_addr & 0x000003ff;              /* 11-0 */
        printk("\nLinearBaseAddress: 0x%08x\n", linear_addr);
        printk("\nDirIndex        TableIndex      Offset\n");
        printk("0x%03x          0x%03x          0x%03x\n", dir_index, table_index, offset);
        /* 页目录表和页表查询 */
        table_item1 = *((unsigned long *)(task[task_index]->tss.cr3 + dir_index * 4));
        table_addr = table_item1 & 0xfffff000;
        table_item2 = *((unsigned long *)(table_addr + table_index * 4));
        page_addr = table_item2 & 0xfffff000;
        phy_addr = (unsigned long *)(page_addr + offset);
        printk("\nTableAddress    PageAddress     PhysicalAddress\n");
        printk("0x%08x     0x%08x     0x%08x\n", table_addr, page_addr, phy_addr);
        printk("\n--------------------------------------------------\n");
    } else if (address == NULL && logPath == NULL) {
        printk("\nPid: %d  Task: %d  LinearBaseAddress: 0x%08x\n", pid, task_index, base_addr);
        linear_addr = base_addr;
        dir_index = linear_addr >> 22;                  /* 31-22 */
        for (int i=dir_index; i<dir_index+16; i++) {
            table_item1 = *((unsigned long *)(task[task_index]->tss.cr3 + i * 4));
            if (table_item1 & 0x1) {
                table_indexes[table_addr_amt] = i;
                table_addrs[table_addr_amt++] = table_item1 & 0xfffff000;
            }
        }
        printk("\nIndex   Table address\n");
        for (int i=0; i<table_addr_amt; i++)
            printk("0x%03x    0x%08x\n", table_indexes[i], table_addrs[i]);
        for (int i=0; i<table_addr_amt; i++) {
            printk("\nTable 0x%08x :\n", table_addrs[i]);
            printk("        Index  Page address\n");
            for (int j=0; j<1024; j++) {
                table_item2 = *((unsigned long *)(table_addrs[i] + j * 4));
                if (table_item2 & 0x1) {
                    page_addr = table_item2 & 0xfffff000;
                    printk("        0x%03x  0x%08x\n", j, page_addr);
                }
            }
        }
        printk("\n--------------------------------------------------\n");
    } else if (address != NULL && logPath != NULL) {
        fp = open(logPath, O_CREAT|O_APPEND|O_WRONLY);
        fprintk(fp, "\nPid: %d  Task: %d  LinearBaseAddress: 0x%08x\n", pid, task_index, base_addr);
        /* 线性地址 */
        linear_addr = base_addr + ((unsigned long)address);
        dir_index = linear_addr >> 22;                  /* 31-22 */
        table_index = (linear_addr & 0x003fffff) >> 12; /* 21-12 */
        offset = linear_addr & 0x000003ff;              /* 11-0 */
        fprintk(fp, "\nLinearBaseAddress: 0x%08x\n", linear_addr);
        fprintk(fp, "\nDirIndex        TableIndex      Offset\n");
        fprintk(fp, "0x%08x     0x%08x     0x%08x\n", dir_index, table_index, offset);
        /* 页目录表和页表查询 */
        table_item1 = *((unsigned long *)(task[task_index]->tss.cr3 + dir_index * 4));
        table_addr = table_item1 & 0xfffff000;
        table_item2 = *((unsigned long *)(table_addr + table_index * 4));
        page_addr = table_item2 & 0xfffff000;
        phy_addr = (unsigned long *)(page_addr + offset);
        fprintk(fp, "\nTableAddress    PageAddress     PhysicalAddress\n");
        fprintk(fp, "0x%03x          0x%03x          0x%03x\n", table_addr, page_addr, phy_addr);
        fprintk(fp, "\n--------------------------------------------------\n");
        close(fp);
    } else {
        fp = open(logPath, O_CREAT|O_APPEND|O_WRONLY);
        fprintk(fp, "\nPid: %d  Task: %d  LinearBaseAddress: 0x%08x\n", pid, task_index, base_addr);
        linear_addr = base_addr;
        dir_index = linear_addr >> 22;                  /* 31-22 */
        for (int i=dir_index; i<dir_index+16; i++) {
            table_item1 = *((unsigned long *)(task[task_index]->tss.cr3 + i * 4));
            if (table_item1 & 0x1) {
                table_indexes[table_addr_amt] = i;
                table_addrs[table_addr_amt++] = table_item1 & 0xfffff000;
            }
        }
        fprintk(fp, "\nIndex   Table address\n");
        for (int i=0; i<table_addr_amt; i++)
            fprintk(fp, "0x%03x    0x%08x\n", table_indexes[i], table_addrs[i]);
        for (int i=0; i<table_addr_amt; i++) {
            fprintk(fp, "\nTable 0x%08x :\n", table_addrs[i]);
            fprintk(fp, "        Index  Page address\n");
            for (int j=0; j<1024; j++) {
                table_item2 = *((unsigned long *)(table_addrs[i] + j * 4));
                if (table_item2 & 0x1) {
                    page_addr = table_item2 & 0xfffff000;
                    fprintk(fp, "        0x%03x  0x%08x\n", j, page_addr);
                }
            }
        }
        fprintk(fp, "\n--------------------------------------------------\n");
        close(fp);
    }
}