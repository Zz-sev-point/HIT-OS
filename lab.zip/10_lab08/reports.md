# 8. 打印进程地址转换过程

## 8.1 实验目的
* 深入理解操作系统的段、页式内存管理，深入理解段表、页表、逻辑地址、线性地址、物理地址等概念；
* 实践段、页式内存管理的地址映射过程；
* 编程打印特定进程地址转换过程。

## 8.2 实验内容

### 8.2.1 系统调用debug_paging的实现

debug_paging()参数如下。其功能：当address为NULL的时候，该系统调用将会打印pid进程所有正在使用的页目录项和页表项。否则只输出address对应的页地址转换过程。当logPath为NULL打印输出为标准输出，否则为logPath对应的文本文件。debug_paging()的具体代码实现见code/debug.c。

```
int debug_paging(pid_t pid, void *address, const char *logPath);
```

1. 打印地址转换过程

通过实验7对test程序地址翻译的跟踪，我们基本知道了虚拟地址转换到最终物理地址的流程：查询数据段基地址结合虚拟地址获得线性地址，在通过页表查询获得最终的物理地址。这里debug_paging()对address的地址转换过程也是类似。

debug_paging()对address地址转换的步骤如下。

* 首先，我们需要通过参数pid查找到对应的任务进程。linux0.11通过一个task数组维护任务进程，该数组有一系列task_struct结构体组成，我们将结构体中的成员pid与参数pid比较判断当前task是否为目标task。若遍历完task数组仍未找到，则报错返回。
  
* 其次，计算段基地址。task_struct结构体中有成员ldt，它也是一个数组，记录了该任务ldt的内容，即各个段的段描述符，其中第2项对应代码段，第3项为数据段/堆栈段。通过将数据段/堆栈段描述符传递给get_base()函数计算获得段基地址。
  
* 接着，计算线性地址。线性地址为段基地址与虚拟地址之和。
  
* 然后，通过线性地址获得页目录表表项索引、页表表项索引和物理内存页的偏移量。
  
* 最后，根据上一步的索引依次到页目录表和页表中查询，即可获得页表地址、物理页地址和最终的物理地址。页目录表的地址需要通过查找cr3获得，而cr3也是结构体task_struct的成员，根据当前pid对应的task查找即可。不过实际上，linux0.11中所有进程共享一个页目录表，故实际上所有task的cr3是相等的。

实现的伪代码如下（省略输出的实现）。

```
if address不为NULL {
    for (int i=0; i<NR_TASKS; i++) {
        根据参数pid在task数组中找到对应的任务
        该任务下标存给task_index
    }
    if 没有找到pid对应的任务 
        报错并返回-1

    /* 段基地址 */
    base_addr = get_base(task[task_index]->ldt[2]);

    /* 线性地址 */
    linear_addr = base_addr + address;

    /* 页目录表项索引，页表项索引，偏移 */
    dir_index = linear_addr[31-22];
    table_index = linear_addr[21-12];
    offset = linear_addr[11-0]; 

    /* 页目录表查询 */
    table_item1 = cr3 + dir_index * 4;
    table_addr = {table_item1[31-12], 0x000};

    /* 页表查询 */
    table_item2 = table_addr + table_index * 4;
    page_addr = {table_item2[31-12], 0x000};

    /* 物理地址 */
    phy_addr = page_addr + offset;
}
```

2. 打印页目录项和页表项

没有了具体的address，我们就需要遍历一个进程所占的所有空间，并列出对应的所有的页目录项和页表项。

* 首先，我们需要确定一个进程占用的线性地址空间。
  
    我们先通过一个简单的实验来确定一个进程占用的线性空间的大小。如图1所示，我们同时运行producer和consumer程序，并利用debug_paing()记录两个程序的ds段基地址（图中的debug_paging已经完全实现，但是我们实际只关心其计算线性基地址的功能），发现为0x10000000和0x14000000，间隔0x4000000；为进一步验证，如图2所示，我们同时运行test、producer和consumer三个程序，并记录它们的ds段基地址，发现为0x10000000、0x14000000和0x18000000，间隔也为0x4000000。

    由此可知，一个进程占线性空间大小为0x4000000，也就是16个页目录表项，故对某个进程，只需以其线性基地址对应的第1项向后检索16项即可。

<div align="center"><img src="images/1.png"><br>Figure 1. producer与consumer程序段基地址</div>
<div align="center"><img src="images/2.png"><br>Figure 2. test、producer与consumer程序段基地址</div>

* 其次，同样利用get_base()获得段基地址，通过基地址的31-22项获得页目录表中的第1项的索引，并再向后检索15项。每一项的最后一位标识该项是否有用，故将最后一位为1的项记录，这些就是该进程所有的页目录项。
  
* 每个页目录项对应的页表都有1024项，遍历每个页表的所有项，其中最后一位标识位为1的项为该进程所用到的页表项，记录之。

实现的伪代码如下。

```
table_indexes[]：记录该进程所有的页目录表项的索引
table_addrs[]: 记录该进程所有的页目录表项
table_addr_amt: 记录该进程页目录表项的数量

if address为NULL {
    for (int i=0; i<NR_TASKS; i++) {
        根据参数pid在task数组中找到对应的任务
        该任务下标存给task_index
    }
    if 没有找到pid对应的任务 
        报错并返回-1
    
    /* 线性基地址 */
    linear_addr = get_base(task[task_index]->ldt[2]);

    /* 页目录表 */
    dir_index = linear_addr[31-22];
    for (int i=dir_index; i<dir_index+16; i++) {
        table_item1 = cr3 + i * 4;
        if table_item1[0]==1 {
            将第i个页目录表项加入到table_addr[]
            更新table_indexes[]和table_addr_amt
        }
    }
    for (int i=0; i<table_addr_amt; i++)
        打印table_addr[i]
    
    /* 页表 */
    for (int i=0; i<table_addr_amt; i++) {
        for (int j=0; j<1024; j++) {
            table_item2 = table_addrs[i] + j * 4;
            if table_item2[0] == 1) 
                打印该项存储的物理页号
        }
    }
}
```

### 8.2.2 添加系统调用

由于此次实验是基于实验7实现的，故需要在实验7修改后的Linux0.11内核中进行进一步修改。

* 将debug.c放入 linux-0.11/kernel 路径下；
* 修改linux-0.11/include/unistd.h文件，即为新添加的1个系统调用设置编号；
```
#define __NR_debug_paging 78
```
* 修改sys.h文件，将1个新的系统调用加入到sys_call_table中；
```
extern int sys_debug_paging();

fn_ptr sys_call_table[] = {...,sys_debug_paging };
```
* 修改linux-0.11/kernel/system_call.s文件，将记录系统调用数的nr_system_calls变量改为79；
```
nr_system_calls = 79
```
* 修改linux-0.11/kernel/Makefile文件，加入对debug.c文件的编译；
```
OBJS  = ... debug.o
debug.s debug.o: debug.c debug.c ../include/linux/kernel.h ../include/linux/sched.h \
  ../include/linux/mm.h ../include/unistd.h
```

### 8.2.3 编写测试程序

test.c程序代码即实验指导所给的代码，具体见code/test.c。

producer.c和consumer.c修改如下。
```
/* producer */
    ...
    shmid = shmget(1234, BUFSIZE);
	printf("shmid:%d\n",shmid);
    if(shmid == -1)
        return -1;
    p = (int*) shmat(shmid);
    debug_paging(getpid(), p, "/usr/var/paging.log");
    debug_paging(getpid(), NULL, "/usr/var/paging.log");
    ...

/* consumer */
    ...
	shmid = shmget(1234, BUFSIZE);
	if(shmid == -1)
        return -1;
    p = (int *)shmat(shmid);
	printf("shmid:%d\n",shmid);
    debug_paging(getpid(), NULL, "/usr/var/paging.log");
    ...
```
### 8.2.3 编译并测试

```
/* 编译内核 */
cd ./linux-0.11
make all

/* 挂载文件 */
cd ..
./mount-hdc
cp unistd.h ./hdc/usr/include/
cp sem.h ./hdc/usr/include/linux
cp producer.c ./hdc/usr/var/
cp consumer.c ./hdc/usr/var/
cp test.c ./hdc/usr/var/

/* 在Linux0.11中编译并运行程序 */
cd ../var/
gcc -o test test.c
gcc -o producer producer.c
gcc -o consumer consumer.c
./test
./producer & ./consumer
```

test运行结果如图3、4所示。

<div align="center"><img src="images/3.png"><br>Figure 3. test测试对i的地址翻译</div>
<div align="center"><img src="images/4.png"><br>Figure 4. test测试列举页目录表项和页表项</div>

producer和consumer测试结果

<div align="center"><img src="images/5.png"><br>Figure 5. 列举consumer页目录表项和页表项</div>
<div align="center"><img src="images/6.png"><br>Figure 6. producer中对p的地址翻译</div>
<div align="center"><img src="images/7.png"><br>Figure 7. 列举producer页目录表项和页表项</div>

## 8.3 实验问题

### 8.3.1 页表中正在使用的页表项是连续的吗？这体现了分页的什么优点？

正在使用的页表项并不一定是连续的。这体现了分页的灵活性，提高了对空间的利用率。

### 8.3.2 你觉的分段是必要的吗？现在的Linux(x86-64)是怎么处理分段的？

我认为是必要的。因为分段可以让程序实现重定位，方便了程序的编译和运行，也使得操作系统对内存空间的利用更加的灵活高效。

linux仅有4个段，即用户代码段，用户数据段，内核代码段，内核数据段。

### 8.3.3 对实验7中“trying to free free page”bug的补充

在实验7中，同时运行producer和consumer后，屏幕会打印“trying to free free page”的错误，原因是两个进程在结束后都尝试释放共享内存页。

释放内存页的函数为linux-0.11/mm/memory.c文件中的free_page()。linux0.11对页的使用和释放通过修改mem_map数组实现，这是一个0/1数组，0代表页空闲，1代表页已经被使用。而在free_page()中并不会检查释放页对应的mem_map中的项的实际值，直接将其减1，则当该页在之前已经被释放时，就会报错。故这里，我们添加对mem_map对应项值的判断，若为1则释放并返回，若为0则直接返回。

```
void free_page(unsigned long addr)
{
	if (addr < LOW_MEM) return;
	if (addr >= HIGH_MEMORY)
		panic("trying to free nonexistent page");
	addr -= LOW_MEM;
	addr >>= 12;
	if (mem_map[addr]){
		mem_map[addr]--;
		return;
	} 
	return;
}
```

